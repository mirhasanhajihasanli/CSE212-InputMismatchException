
public interface CustomerSavings {
	public void calculateSavingsPerItem();
	public void displayAllRentals();

}
